/*****************************************************************************
* File Name: main.c
*
* Version: 3.0
*
* Description:
*   The main C file for the Temperature measurement with Thermistor project. 
* 
* Note:
* 	The main project includes the ADC and other components required for the
*   temperature measurement. The Thermistor component is a complete firmware component
*   as decribed in the component datahseet and application note
******************************************************************************
* Copyright (C) 2015, Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/
#include <device.h>
#include "removeOffsetNoise.h"
#include "measurement.h"
#include <stdio.h>

#define myBufferSize 64

uint8_t stringCapSensorsOnOff[1];
uint8_t stringCapSensorsRaw[16];

uint8 MyArray[myBufferSize];


int main(void)
{
	int32 iVref, iVtherm;
	uint32 iRes;

	char printBuf[16]={'\0'};


	CYGlobalIntEnable; 
	

	ADC_Start();
	AMux_Start();

	VDAC8_Start();
	Opamp_Start();

    EZI2C_Start();      
    
    EZI2C_SetBuffer1(sizeof(MyArray), myBufferSize, (void *) MyArray);

    CyDelay(500);
    CapSense_Start();        
    CapSense_InitializeAllBaselines() ;
    
    CapSense_ScanEnabledWidgets() ;    
    LED_Write(1);
	for(;;)
    {

        //LED_Write(1);
    	//iVtherm = MeasureResistorVoltage(AMUX_1_VT); 
    	//iVref = MeasureResistorVoltage(AMUX_1_VREF);
		//iRes = (int32)(((float)iVtherm / iVref) * REFERENCE_RESISTOR);
   
        if(CapSense_IsBusy() == 0)        //if scan is complete   
        {             
            uint8_t byteCounter = 0;
            for (uint8_t i = 0; i < 8; i++)
            {
                uint16 tempVar = CapSense_ReadSensorRaw(i);
                CapSense_CheckIsSensorActive(i);
                stringCapSensorsRaw[byteCounter++] = tempVar >> 8;
                
                stringCapSensorsRaw[byteCounter++] = tempVar & 0xff;
                
            }

            //LED_Write(0);
            CapSense_UpdateEnabledBaselines();
            CapSense_ScanEnabledWidgets();  
            
        }   
            
        if ((EZI2C_GetActivity() & EZI2C_STATUS_BUSY) == 0)
        {
           for (uint8_t i = 0; i < 16; i++)
            {
                MyArray[i] = stringCapSensorsRaw[i];
            }
            MyArray[16] = CapSense_sensorOnMask[0];
        }
    }
}

/* [] END OF FILE */
